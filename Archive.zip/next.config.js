const webpack = require('webpack');
module.exports = {
  i18n: {
    localeDetection: false,
    locales: ["en", "es"],
    defaultLocale: "en",
    domains: [
      {
        domain: 'busbooking.se',
        defaultLocale: 'en',
        http: true,
      },
      {
        domain: 'busbooking.se',
        defaultLocale: 'es',
        http: true,
      },
    ],
  },
  webpack: (config, { buildId, dev, isServer, defaultLoaders, webpack }) => {
    config.plugins.push(new webpack.ProvidePlugin({
            $: 'jquery',
            jQuery: 'jquery',
            'window.jQuery': 'jquery'
        }))
    return config;
  },
};
